/************************************************************************
Author   : mike
Email    : hxtiou@163.com	
Version  : V1.0
Date     : 2019-07-12
Note     : 
*************************************************************************/
#include "includes.h"


void spi_delay_us(u8 us)
{
	u8 i,j;
	for(i=0;i<us;i++)
			for(j=0;j<5;j++);    
}

void spi_InitGpio(void)
{
    // SDA	��������
    P1MDOUT |= 0X04;   /* P1.2�������ݷ���Ĵ��� 1Ϊ�����0Ϊ����*/
	// SCL	ʱ��
    P1MDOUT |= 0X02;   /* P1.1�������ݷ���Ĵ��� 1Ϊ�����0Ϊ����*/
	// CS 	�͵�ƽ��Ч
    P1MDOUT |= 0X01;   /* P1.0�������ݷ���Ĵ��� 1Ϊ�����0Ϊ����*/
	// RST 	�͵�ƽ��Ч
    P1MDOUT |= 0X08;   /* P1.3�������ݷ���Ĵ��� 1Ϊ�����0Ϊ����*/

    SDA = 1;
	SCL = 0;
	CS = 1;
	RST = 1;
}

void spi_st7701s_SendData(u8 i)
{
	unsigned char n;
    for(n = 0; n < 8; n++) {
        if(i & 0x80) {
            SDA = 1;
        } else {
            SDA = 0;
        }

        i<<= 1;
        spi_delay_us(10);
        SCL = 1;
        spi_delay_us(10);
        SCL = 0;
        spi_delay_us(10);
    }
}

void spi_st7701s_WriteCommand( u8 i)
{
	CS = 0;
    spi_delay_us(10);
    SDA = 0;
    spi_delay_us(10);
	SCL = 1;
	spi_delay_us(10);
	SCL = 0;
	spi_delay_us(10);

	spi_st7701s_SendData(i);
    spi_delay_us(10);

    CS = 1;	
    spi_delay_us(10);
}

void spi_st7701s_WriteData( u8 i)
{

	CS = 0;
    spi_delay_us(10);
	SDA = 1;
    spi_delay_us(10);
	SCL = 1;
	spi_delay_us(10);
	SCL = 0;
	spi_delay_us(10);
	spi_st7701s_SendData(i); 
    spi_delay_us(10);
	CS = 1;	
    spi_delay_us(10);
}

void Write(u8 unuse, u8 _data)
{

	if (unuse) {
		spi_st7701s_WriteData(_data);

	} else {
		spi_st7701s_WriteCommand(_data);
	}
	spi_delay_us(100);
//	ssd2828_writecmd(unuse, _data);
	return;
}

void spi_RST(void)
{
	RST = 1;
    Delay_ms (1);
	RST = 0;
    Delay_ms (1);
	RST = 1;
    Delay_ms (120);
	Write(0 ,0x11); //д����
    Delay_ms (120);
}

void screen_init(void)
{
	u8 Command;
	u8 Parameter;

	Command = 0;
	Parameter = 1;

	Delay_ms(120);                //msWriteComm (0xFF);
	Write(Command,0xFF);
	Write(Parameter,0x77);
	Write(Parameter,0x01);
	Write(Parameter,0x00);
	Write(Parameter,0x00);
	Write(Parameter,0x13);
	Write(Command,0xEF);
	Write(Parameter,0x08);
	Write(Command,0xFF);
	Write(Parameter,0x77);
	Write(Parameter,0x01);
	Write(Parameter,0x00);
	Write(Parameter,0x00);
	Write(Parameter,0x10);
	Write(Command,0xC0);
	Write(Parameter,0x3B);
	Write(Parameter,0x00);
	Write(Command,0xC1);
	Write(Parameter,0x0D);
	Write(Parameter,0x02);
	Write(Command,0xC2);
	Write(Parameter,0x21);
	Write(Parameter,0x08);
	Write(Command,0xCD);
	Write(Parameter,0x08);//18-bit/pixel: MDT=0:D[21:16]=R,D[13:8]=G,D[5:0]=B(CDH=00) ;

                 //              MDT=1:D[17:12]=R,D[11:6]=G,D[5:0]=B(CDH=08) ;


	Write(Command,0xB0);
	Write(Parameter,0x00);
	Write(Parameter,0x11);
	Write(Parameter,0x18);
	Write(Parameter,0x0E);
	Write(Parameter,0x11);
	Write(Parameter,0x06);
	Write(Parameter,0x07);
	Write(Parameter,0x08);
	Write(Parameter,0x07);
	Write(Parameter,0x22);
	Write(Parameter,0x04);
	Write(Parameter,0x12);
	Write(Parameter,0x0F);
	Write(Parameter,0xAA);
	Write(Parameter,0x31);
	Write(Parameter,0x18);
	Write(Command,0xB1);
	Write(Parameter,0x00);
	Write(Parameter,0x11);
	Write(Parameter,0x19);
	Write(Parameter,0x0E);
	Write(Parameter,0x12);
	Write(Parameter,0x07);
	Write(Parameter,0x08);
	Write(Parameter,0x08);
	Write(Parameter,0x08);
	Write(Parameter,0x22);
	Write(Parameter,0x04);
	Write(Parameter,0x11);
	Write(Parameter,0x11);
	Write(Parameter,0xA9);
	Write(Parameter,0x32);
	Write(Parameter,0x18);
	Write(Command,0xFF);
	Write(Parameter,0x77);
	Write(Parameter,0x01);
	Write(Parameter,0x00);
	Write(Parameter,0x00);
	Write(Parameter,0x11);
	Write(Command,0xB0);
	Write(Parameter,0x60);
	Write(Command,0xB1);
	Write(Parameter,0x30);
	Write(Command,0xB2);
	Write(Parameter,0x87);
	Write(Command,0xB3);
	Write(Parameter,0x80);
	Write(Command,0xB5);
	Write(Parameter,0x49);
	Write(Command,0xB7);
	Write(Parameter,0x85);
	Write(Command,0xB8);
	Write(Parameter,0x21);
	Write(Command,0xC1);
	Write(Parameter,0x78);
	Write(Command,0xC2);
	Write(Parameter,0x78);
	Delay_ms(20);
	Write(Command,0xE0);
	Write(Parameter,0x00);
	Write(Parameter,0x1B);
	Write(Parameter,0x02);
	Write(Command,0xE1);
	Write(Parameter,0x08);
	Write(Parameter,0xA0);
	Write(Parameter,0x00);
	Write(Parameter,0x00);
	Write(Parameter,0x07);
	Write(Parameter,0xA0);
	Write(Parameter,0x00);
	Write(Parameter,0x00);
	Write(Parameter,0x00);
	Write(Parameter,0x44);
	Write(Parameter,0x44);
	Write(Command,0xE2);
	Write(Parameter,0x11);
	Write(Parameter,0x11);
	Write(Parameter,0x44);
	Write(Parameter,0x44);
	Write(Parameter,0xED);
	Write(Parameter,0xA0);
	Write(Parameter,0x00);
	Write(Parameter,0x00);
	Write(Parameter,0xEC);
	Write(Parameter,0xA0);
	Write(Parameter,0x00);
	Write(Parameter,0x00);
	Write(Command,0xE3);
	Write(Parameter,0x00);
	Write(Parameter,0x00);
	Write(Parameter,0x11);
	Write(Parameter,0x11);
	Write(Command,0xE4);
	Write(Parameter,0x44);
	Write(Parameter,0x44);
	Write(Command,0xE5);
	Write(Parameter,0x0A);
	Write(Parameter,0xE9);
	Write(Parameter,0xD8);
	Write(Parameter,0xA0);
	Write(Parameter,0x0C);
	Write(Parameter,0xEB);
	Write(Parameter,0xD8);
	Write(Parameter,0xA0);
	Write(Parameter,0x0E);
	Write(Parameter,0xED);
	Write(Parameter,0xD8);
	Write(Parameter,0xA0);
	Write(Parameter,0x10);
	Write(Parameter,0xEF);
	Write(Parameter,0xD8);
	Write(Parameter,0xA0);
	Write(Command,0xE6);
	Write(Parameter,0x00);
	Write(Parameter,0x00);
	Write(Parameter,0x11);
	Write(Parameter,0x11);
	Write(Command,0xE7);
	Write(Parameter,0x44);
	Write(Parameter,0x44);
	Write(Command,0xE8);
	Write(Parameter,0x09);
	Write(Parameter,0xE8);
	Write(Parameter,0xD8);
	Write(Parameter,0xA0);
	Write(Parameter,0x0B);
	Write(Parameter,0xEA);
	Write(Parameter,0xD8);
	Write(Parameter,0xA0);
	Write(Parameter,0x0D);
	Write(Parameter,0xEC);
	Write(Parameter,0xD8);
	Write(Parameter,0xA0);
	Write(Parameter,0x0F);
	Write(Parameter,0xEE);
	Write(Parameter,0xD8);
	Write(Parameter,0xA0);
	Write(Command,0xEB);
	Write(Parameter,0x02);
	Write(Parameter,0x00);
	Write(Parameter,0xE4);
	Write(Parameter,0xE4);
	Write(Parameter,0x88);
	Write(Parameter,0x00);
	Write(Parameter,0x40);
	Write(Command,0xEC);
	Write(Parameter,0x3C);
	Write(Parameter,0x00);
	Write(Command,0xED);
	Write(Parameter,0xAB);
	Write(Parameter,0x89);
	Write(Parameter,0x76);
	Write(Parameter,0x54);
	Write(Parameter,0x02);
	Write(Parameter,0xFF);
	Write(Parameter,0xFF);
	Write(Parameter,0xFF);
	Write(Parameter,0xFF);
	Write(Parameter,0xFF);
	Write(Parameter,0xFF);
	Write(Parameter,0x20);
	Write(Parameter,0x45);
	Write(Parameter,0x67);
	Write(Parameter,0x98);
	Write(Parameter,0xBA);
//---------------------------------------------GIP Setting END----------------------------------------------------//
	Write(Command,0x36);  // Display data access control
	Write(Parameter,0x00);
	Write(Command,0x29);  //Display On








//	Write(Command ,0xFF);
//	Write(Parameter ,0x77);
//	Write(Parameter ,0x01);
//	Write(Parameter ,0x00);
//	Write(Parameter ,0x00);
//	Write(Parameter ,0x13);
//	Write(Command ,0xEF);
//	Write(Parameter ,0x08);
//	Write(Command ,0xFF);
//	Write(Parameter ,0x77);
//	Write(Parameter ,0x01);
//	Write(Parameter ,0x00);
//	Write(Parameter ,0x00);
//	Write(Parameter ,0x10);
//	Write(Command ,0xC0);
//	Write(Parameter ,0xE9);
//	Write(Parameter ,0x03);
//	Write(Command ,0xC1);
//	Write(Parameter ,0x12);//10
//	Write(Parameter ,0x0C);
//	Write(Command ,0xC2);
//	Write(Parameter ,0x20);
//	Write(Parameter ,0x0A);
//	Write(Command ,0xC7);
//	Write(Parameter ,0x04);
//	Write(Command ,0xCC);
//	Write(Parameter ,0x10);
//	Write(Command ,0xB0);
//	Write(Parameter ,0x00);
//	Write(Parameter ,0x23);
//	Write(Parameter ,0x2A);
//	Write(Parameter ,0x0A);
//	Write(Parameter ,0x0E);
//	Write(Parameter ,0x03);
//	Write(Parameter ,0x12);
//	Write(Parameter ,0x06);
//	Write(Parameter ,0x06);
//	Write(Parameter ,0x2A);
//	Write(Parameter ,0x00);
//	Write(Parameter ,0x10);
//	Write(Parameter ,0x0F);
//	Write(Parameter ,0x2D);
//	Write(Parameter ,0x34);
//	Write(Parameter ,0x1F);
//	Write(Command ,0xB1);
//	Write(Parameter ,0x00);
//	Write(Parameter ,0x24);
//	Write(Parameter ,0x2B);
//	Write(Parameter ,0x0F);
//	Write(Parameter ,0x12);
//	Write(Parameter ,0x07);
//	Write(Parameter ,0x15);
//	Write(Parameter ,0x0A);
//	Write(Parameter ,0x0A);
//	Write(Parameter ,0x2B);
//	Write(Parameter ,0x08);
//	Write(Parameter ,0x13);
//	Write(Parameter ,0x10);
//	Write(Parameter ,0x2D);
//	Write(Parameter ,0x33);
//	Write(Parameter ,0x1F);
//	Write(Command ,0xFF);
//	Write(Parameter ,0x77);
//	Write(Parameter ,0x01);
//	Write(Parameter ,0x00);
//	Write(Parameter ,0x00);
//	Write(Parameter ,0x11);
//	Write(Command ,0xB0);
//	Write(Parameter ,0x4D);
//	Write(Command ,0xB1);
//	Write(Parameter ,0x43);
//	Write(Command ,0xB2);
//	Write(Parameter ,0x84);
//	Write(Command ,0xB3);
//	Write(Parameter ,0x80);
//	Write(Command ,0xB5);
//	Write(Parameter ,0x45);
//	Write(Command ,0xB7);
//	Write(Parameter ,0x85);
//	Write(Command ,0xB8);
//	Write(Parameter ,0x33);
//	Write(Command ,0xC1);
//	Write(Parameter ,0x78);
//	Write(Command ,0xC2);
//	Write(Parameter ,0x78);
//	Write(Command ,0xD0);
//	Write(Parameter ,0x88);
//	Write(Command ,0xE0);
//	Write(Parameter ,0x00);
//	Write(Parameter ,0x00);
//	Write(Parameter ,0x02);
//	Write(Command ,0xE1);
//	Write(Parameter ,0x06);
//	Write(Parameter ,0xA0);
//	Write(Parameter ,0x08);
//	Write(Parameter ,0xA0);
//	Write(Parameter ,0x05);
//	Write(Parameter ,0xA0);
//	Write(Parameter ,0x07);
//	Write(Parameter ,0xA0);
//	Write(Parameter ,0x00);
//	Write(Parameter ,0x44);
//	Write(Parameter ,0x44);
//	Write(Command ,0xE2);
//	Write(Parameter ,0x30);
//	Write(Parameter ,0x30);
//	Write(Parameter ,0x44);
//	Write(Parameter ,0x44);
//	Write(Parameter ,0x6E);
//	Write(Parameter ,0xA0);
//	Write(Parameter ,0x00);
//	Write(Parameter ,0x00);
//	Write(Parameter ,0x6E);
//	Write(Parameter ,0xA0);
//	Write(Parameter ,0x00);
//	Write(Parameter ,0x00);
//	Write(Command ,0xE3);
//	Write(Parameter ,0x00);
//	Write(Parameter ,0x00);
//	Write(Parameter ,0x33);
//	Write(Parameter ,0x33);
//	Write(Command ,0xE4);
//	Write(Parameter ,0x44);
//	Write(Parameter ,0x44);
//	Write(Command ,0xE5);
//	Write(Parameter ,0x0D);
//	Write(Parameter ,0x69);
//	Write(Parameter ,0x0A);
//	Write(Parameter ,0xA0);
//	Write(Parameter ,0x0F);
//	Write(Parameter ,0x6B);
//	Write(Parameter ,0x0A);
//	Write(Parameter ,0xA0);
//	Write(Parameter ,0x09);
//	Write(Parameter ,0x65);
//	Write(Parameter ,0x0A);
//	Write(Parameter ,0xA0);
//	Write(Parameter ,0x0B);
//	Write(Parameter ,0x67);
//	Write(Parameter ,0x0A);
//	Write(Parameter ,0xA0);
//	Write(Command ,0xE6);
//	Write(Parameter ,0x00);
//	Write(Parameter ,0x00);
//	Write(Parameter ,0x33);
//	Write(Parameter ,0x33);
//	Write(Command ,0xE7);
//	Write(Parameter ,0x44);
//	Write(Parameter ,0x44);
//	Write(Command ,0xE8);
//	Write(Parameter ,0x0C);
//	Write(Parameter ,0x68);
//	Write(Parameter ,0x0A);
//	Write(Parameter ,0xA0);
//	Write(Parameter ,0x0E);
//	Write(Parameter ,0x6A);
//	Write(Parameter ,0x0A);
//	Write(Parameter ,0xA0);
//	Write(Parameter ,0x08);
//	Write(Parameter ,0x64);
//	Write(Parameter ,0x0A);
//	Write(Parameter ,0xA0);
//	Write(Parameter ,0x0A);
//	Write(Parameter ,0x66);
//	Write(Parameter ,0x0A);
//	Write(Parameter ,0xA0);
//	Write(Command ,0xE9);
//	Write(Parameter ,0x36);
//	Write(Parameter ,0x00);
//	Write(Command ,0xEB);
//	Write(Parameter ,0x00);
//	Write(Parameter ,0x01);
//	Write(Parameter ,0xE4);
//	Write(Parameter ,0xE4);
//	Write(Parameter ,0x44);
//	Write(Parameter ,0x88);
//	Write(Parameter ,0x40);
//	Write(Command ,0xED);
//	Write(Parameter ,0xFF);
//	Write(Parameter ,0x45);
//	Write(Parameter ,0x67);
//	Write(Parameter ,0xFB);
//	Write(Parameter ,0x01);
//	Write(Parameter ,0x2A);
//	Write(Parameter ,0xFC);
//	Write(Parameter ,0xFF);
//	Write(Parameter ,0xFF);
//	Write(Parameter ,0xCF);
//	Write(Parameter ,0xA2);
//	Write(Parameter ,0x10);
//	Write(Parameter ,0xBF);
//	Write(Parameter ,0x76);
//	Write(Parameter ,0x54);
//	Write(Parameter ,0xFF);
//	Write(Command ,0xEF);
//	Write(Parameter ,0x10);
//	Write(Parameter ,0x0D);
//	Write(Parameter ,0x04);
//	Write(Parameter ,0x08);
//	Write(Parameter ,0x3F);
//	Write(Parameter ,0x1F);
//	Write(Command ,0x36);
//	Write(Parameter ,0x10);
//	Write(Command ,0x3A);Write(Parameter ,0x55);
//	Write(Command ,0x11);
//	delay_ms(120);
//	Write(Command ,0x29);
//	Write(Command ,0x35);
//	Write(Parameter ,0x00);
	return;
}

void screen_spi_init(void)
{
  spi_InitGpio();
	spi_RST();
	screen_init();//Һ������ʼ������
}
