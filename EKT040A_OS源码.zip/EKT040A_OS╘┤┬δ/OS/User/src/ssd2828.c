#include "includes.h"
#include "ssd2828.h"


sbit csx = P1^0;		//p1.0
sbit sdo = P1^1;		//p1.1
sbit sdi = P1^2;		//p1.2
sbit sck = P1^3;		//p1.3
sbit sdc = P1^4;		//p1.4


bit ssd2828_cfg_ok=0;


//����640x480 3.5����
code const u8 pa_tab1[]={0xB9,0xF1,0x12,0x83};
code const u8 pa_tab2[]={0xBA,0x33,0x81,0x05,0xf9,0x0E,0x0E,0x20,0x00,0x00,
												 0x00,0x00,0x00,0x00,0x00,0x44,0x25,0x00,0x91,0x0A,
												 0x00,0x00,0x02,0x4f,0xD1,0x00,0x00,0x37};
code const u8 pa_tab3[]={0xB8,0x76};
code const u8 pa_tab4[]={0xBF,0x02,0x11,0x00};
code const u8 pa_tab5[]={0xB3,0x0C,0x10,0x0A,0x50,0x03,0xFF,0x00,0x00,
												 0x00,0x00};
code const u8 pa_tab6[]={0xC0,0x73,0x73,0x50,0x50,0x00,0x00,0x08,0x70,
												 0x00};	
code const u8 pa_tab7[]={0xBC,0x46};	
code const u8 pa_tab8[]={0xCC,0x0B};	
code const u8 pa_tab9[]={0xB4,0x80};	
code const u8 pa_tab10[]={0xB2,0x00,0x13,0xF0};	
code const u8 pa_tab11[]={0xE3,0x07,0x07,0x0B,0x0B,0x03,0x0B,0x00,0x00,0x00,
													0x00,0xFF,0x00,0xC0,0x10};	                                 
code const u8 pa_tab12[]={0xC1,0x53,0x00,0x1E,0x1E,0x77,0xE1,0xCC,0xDD,0x67,
													0x77,0x33,0x33};
code const u8 pa_tab13[]={0xB5,0x10,0x10}; 
code const u8 pa_tab14[]={0xB6,0x6C,0x7C};
code const u8 pa_tab15[]={0xE9,0x08,0x00,0x0E,0x00,0x00,0xB0,0xB1,0x11,0x31,
													0x23,0x28,0x10,0xB0,0xB1,0x27,0x08,0x00,0x04,0x02,
													0x00,0x00,0x00,0x00,0x04,0x02,0x00,0x00,0x00,0x88,
													0x88,0xBA,0x60,0x24,0x08,0x88,0x88,0x88,0x88,0x88,
													0x88,0x88,0xBA,0x71,0x35,0x18,0x88,0x88,0x88,0x88,
													0x88,0x00,0x00,0x00,0x01,0x00,0x00,0x00,0x00,0x00,
													0x00,0x00,0x00,0x00};
code const u8 pa_tab16[]={0xEA,0x97,0x0A,0x82,0x02,0x13,0x07,0x00,0x00,0x00,
													0x00,0x00,0x00,0x80,0x88,0xba,0x17,0x53,0x88,0x88,
													0x88,0x88,0x88,0x88,0x81,0x88,0xba,0x06,0x42,0x88,
													0x88,0x88,0x88,0x88,0x88,0x23,0x10,0x00,0x02,0x80,
													0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
													0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
													0x00,0x00};
code const u8 pa_tab17[]={0xe0,0x00,0x07,0x0b,0x27,0x2D,0x3F,0x3B,0x37,0x05,
													0x0A,0x0B,0x0F,0x11,0x0F,0x12,0x12,0x18,0x00,0x07,
													0x0B,0x27,0x2D,0x3F,0x3B,0x37,0x05,0x0A,0x0B,0x0F,
													0x11,0x0F,0x12,0x12,0x18}; 
code const u8 pa_tab18[]={0x11};
code const u8 pa_tab19[]={0x29};




#if 0
void delay_us(u8 t){
	u8 i,j;
	for(i=0;i<t;i++){
		for(j=0;j<4;j++);
	}
}
#endif

u16 ssd2828_readID(void){
	u16 ssd2828_id=0,reg_temp=0xb0fa;
	u8 i;
	csx=0;
	sdc=0;		//??
	delay_us(5);
	for(i=0;i<16;i++){
		
		if(reg_temp&0x8000)		//msb
			sdi=1;
		else
			sdi=0;
		sck=0;
		delay_us(5);
		sck=1;
		delay_us(5);
		reg_temp<<=1;			//???
	}
	sdc=1;
	delay_us(5);
	for(i=0;i<16;i++){
		sck=0;
		delay_us(5);
		sck=1;
		delay_us(5);
		ssd2828_id<<=1;
		if(sdo)
			ssd2828_id|=1;
	}
	csx=1;
	delay_us(5);
	return ssd2828_id;
}

u16 ssd2828_readReg(u8 addr_reg){
	u16 reg_value=0,reg_temp;
	u8 i;
	reg_temp=0x00fa|(addr_reg<<8);
	csx=0;
	sdc=0;		//??
	delay_us(5);
	for(i=0;i<16;i++){
		
		if(reg_temp&0x8000)		//msb
			sdi=1;
		else
			sdi=0;
		sck=0;
		delay_us(5);
		sck=1;
		delay_us(5);
		reg_temp<<=1;			//???
	}
	sdc=1;
	delay_us(5);
	for(i=0;i<16;i++){
		sck=0;
		delay_us(5);
		sck=1;
		delay_us(5);
		reg_value<<=1;
		if(sdo)
			reg_value|=1;
	}
	csx=1;
	delay_us(5);
	return reg_value;	
}

void ssd2828_writecmd(u8 cmd){
	u8 i,ssd2828_cmd;
	ssd2828_cmd=cmd;
	csx=0;
	sdc=0;
	delay_us(5);
	for(i=0;i<8;i++){
		if(ssd2828_cmd&0x80)
			sdi=1;
		else
			sdi=0;
		sck=0;
		delay_us(5);
		sck=1;
		delay_us(5);
		ssd2828_cmd<<=1;	
	}
	csx=1;
	delay_us(5);
}

void ssd2828_regconfig(u8 reg_addr,u16 reg_data){
	u8 i,addr_temp,data_H,data_L;
	addr_temp=reg_addr;
	data_H=reg_data>>8;
	data_L=reg_data;
	csx=0;
	sdc=0;
	delay_us(5);
	for(i=0;i<8;i++){		//???????
		if(addr_temp&0x80)
			sdi=1;
		else
			sdi=0;
		sck=0;
		delay_us(5);
		sck=1;
		delay_us(5);
		addr_temp<<=1;
	}
	sdc=1;
	delay_us(5);
	for(i=0;i<8;i++){		//lsb
		if(data_L&0x80)
			sdi=1;
		else
			sdi=0;
		sck=0;
		delay_us(5);
		sck=1;
		delay_us(5);
		data_L<<=1;
	}
	for(i=0;i<8;i++){
		if(data_H&0x80)
			sdi=1;
		else
			sdi=0;
		sck=0;
		delay_us(5);
		sck=1;
		delay_us(5);
		data_H<<=1;
	}
	csx=1;
	delay_us(5);
}

void ssd2828_writepackage(u8 *pbuf,u16 len){
	u16 lenth;
	u8 i,temp;
	lenth=len;
	ssd2828_regconfig(0xbc,lenth);
	ssd2828_regconfig(0xbe,lenth);
	ssd2828_writecmd(0xbf);
	csx=0;
	sdc=1;
	delay_us(5);
	while(lenth--){
		temp=*pbuf++;
		for(i=0;i<8;i++){
			if(temp&0x80)
				sdi=1;
			else
				sdi=0;
			sck=0;
			delay_us(5);
			sck=1;
			delay_us(5);
			temp<<=1;
		}
	}
	csx=1;
	delay_us(5);
}

void W_COM(u8 cmd,u8 val)
{
	u8 i;
	ssd2828_regconfig(0xb7,0x0250);
	ssd2828_regconfig(0xbc,0x0002);
	ssd2828_regconfig(0xbd,0x0000);
	ssd2828_writecmd(0xbf);
	csx=0;
	sdc=1;
	for(i=0;i<8;i++)
	{
		if(cmd&0x80)
			sdi=1;
		else
			sdi=0;
		sck=0;
		delay_us(15);
		sck=1;
		delay_us(15);
		cmd<<=1;
	}
	csx=1;
	delay_us(15);
	for(i=0;i<8;i++)
	{
		if(val&0x80)
			sdi=1;
		else
			sdi=0;
		sck=0;
		delay_us(15);
		sck=1;
		delay_us(15);
		val<<=1;
	}
	csx=1;
	delay_us(15);
	
	Delay_ms(10);
}

/******************************************
	ssd2828����Ϊnon-burst mode��NVD=0,BLLP=0
	ssd2828���ڴ�ֱ�����ڼ䷢�ͷ���Ƶ���ݰ�
*******************************************/
u16 ssd2828_read_mipi(u16 mipi_reg){		//����ȡһ����
	u16 reg_value=0,mipi_reg_value=0;
	u8 mipi_read_cnt=0;
	do{
		ssd2828_regconfig(0xb7,0x02CB);		//REN=1
//		ssd2828_regconfig(0xbb,0x0002);		//�趨�������ʣ��������ͼ����С
		ssd2828_regconfig(0xc1,0x0001);		//���ö�ȡmipi slave���ݵ���󳤶�
//		ssd2828_regconfig(0xc0,0x0100);		//ֹͣ��ͼ��׼����ȡmipi slave�Ĵ���
		ssd2828_regconfig(0xbc,0x0001);		//���ô���ȡ���ݰ�����
		ssd2828_regconfig(0xbf,mipi_reg);		//��ȡmipi slave�Ĵ���
		ssd2828_regconfig(0xd4,0x00fa);		//��λSPI���Ĵ���
		reg_value=ssd2828_readReg(0xc6);
		reg_value&=0x01;		//RDR=0xc6.0
		mipi_read_cnt++;
	} while((reg_value==0)&&(mipi_read_cnt<3));
	//RDR=1�������mipi slave�ѻظ�
	mipi_reg_value=ssd2828_readReg(0xff);	//mipi slave���ص����ݴ洢��0xff�Ĵ�����ַ
	ssd2828_regconfig(0xb7,0x024b);				//�ָ�������ʾ
	return mipi_reg_value;
}

void W_write()
{
W_COM(0xB0,0x5A);

}


void C080_code_download(void)
{
	ssd2828_writepackage(pa_tab1,sizeof(pa_tab1));
	ssd2828_writepackage(pa_tab2,sizeof(pa_tab2));
	ssd2828_writepackage(pa_tab3,sizeof(pa_tab3));
	ssd2828_writepackage(pa_tab4,sizeof(pa_tab4));
	ssd2828_writepackage(pa_tab5,sizeof(pa_tab5));
	ssd2828_writepackage(pa_tab6,sizeof(pa_tab6));
  ssd2828_writepackage(pa_tab7,sizeof(pa_tab7));
	ssd2828_writepackage(pa_tab8,sizeof(pa_tab8));
	ssd2828_writepackage(pa_tab9,sizeof(pa_tab9));
	ssd2828_writepackage(pa_tab10,sizeof(pa_tab10));
	ssd2828_writepackage(pa_tab11,sizeof(pa_tab11));
	ssd2828_writepackage(pa_tab12,sizeof(pa_tab12));
	ssd2828_writepackage(pa_tab13,sizeof(pa_tab13));
	ssd2828_writepackage(pa_tab14,sizeof(pa_tab14));
	ssd2828_writepackage(pa_tab15,sizeof(pa_tab15));
	ssd2828_writepackage(pa_tab16,sizeof(pa_tab16));
  ssd2828_writepackage(pa_tab17,sizeof(pa_tab17));
	ssd2828_writepackage(pa_tab18,sizeof(pa_tab18));
	ssd2828_writepackage(pa_tab19,sizeof(pa_tab19));
	Delay_ms(100);
	
}

void lcd_pa_set(void){
	u8 lcd_vs,lcd_hs,lcd_vbp,lcd_hbp,lcd_vfp,lcd_hfp;
	u16 lcd_sw,lcd_bp,lcd_fp;
	lcd_vs=VS;
	lcd_hs=HS;
	lcd_vbp=VBP;
	lcd_hbp=HBP;
	lcd_vfp=VFP;
	lcd_hfp=HFP;
	lcd_sw=(lcd_vs<<8)| lcd_hs;
	lcd_bp=(lcd_vbp<<8)| lcd_hbp;
	lcd_fp=(lcd_vfp<<8)| lcd_hfp;
	
	ssd2828_regconfig(0xb1,lcd_sw);			//H:VSA,L:HSA
	ssd2828_regconfig(0xb2,lcd_bp);			//H:VBP,L:HBP
	ssd2828_regconfig(0xb3,lcd_fp);			//H:VFP,L:HFP
	ssd2828_regconfig(0xb4,HACT);			//HACT
	ssd2828_regconfig(0xb5,VACT);			//VACT
	ssd2828_regconfig(0xb6,0x00D3);			
}

void ssd2828_init(void)
{
	u16 temp=0;
	
	SetPinOut(1,0);
	SetPinIn(1,1);
	SetPinOut(1,2);
	SetPinOut(1,3);
	SetPinOut(1,4);
	csx=1;
	sdo=0;
	sdi=1;
	sck=1;
	sdc=1;
	Delay_ms(100);
#if 1
	
	temp=ssd2828_readID();
	if(temp!=0x2828)
		return;
#endif
	ssd2828_regconfig(0xb7,0x0050);
	ssd2828_regconfig(0xb8,0x0000);
	ssd2828_regconfig(0xb9,0x0000);
	ssd2828_regconfig(0xba,0x4014);
	ssd2828_regconfig(0xbb,0x0003);
	ssd2828_regconfig(0xb9,0x0001);
	ssd2828_regconfig(0xde,0x0003);//
	ssd2828_regconfig(0xc9,0x2302);
	Delay_ms(100);
	C080_code_download();
	
	ssd2828_regconfig(0xb7,0x0151);
	ssd2828_regconfig(0xb8,0x0000);
	ssd2828_regconfig(0xb9,0x0000);
	ssd2828_regconfig(0xba,0x4012);				//0X804B
	ssd2828_regconfig(0xbb,0x0002);
	ssd2828_regconfig(0xb9,0x0001);
	ssd2828_regconfig(0xc9,0x2302);
	ssd2828_regconfig(0xca,0x2301);		//MIPI????
	ssd2828_regconfig(0xcb,0x0510);
	ssd2828_regconfig(0xcc,0x1005);
	ssd2828_regconfig(0xD0,0x00FF);
	lcd_pa_set();		//??LCD?????
	

	ssd2828_regconfig(0xde,0x0003);		//4 lane

	ssd2828_regconfig(0xd6,0x0004);		//04=BGR 05=RGB
	ssd2828_regconfig(0xb7,0x024B);//
	Delay_ms(100);
	ssd2828_writecmd(0x2c);

	ssd2828_cfg_ok=1;
}

