#ifndef __SSD2828_H__
#define __SSD2828_H__

#define bist 0	//ssd2828 bist mode

extern bit ssd2828_cfg_ok;


#define VFP 0x11 //30		//0x1D
#define VBP 0x0D  //10		//0x1A 
#define VS  0x05		//0x19

#define HFP 0x78 //18		//0x18
#define HBP 0x78 //18		//0x15
#define HS 	0x78 //18		//0x14

#define VACT 480	//0x1B-0x1C
#define HACT 640	//0x16-0x17


void ssd2828_init(void);
u16 ssd2828_read_mipi(u16 mipi_reg);
u16 ssd2828_readReg(u8 addr_reg);




#endif