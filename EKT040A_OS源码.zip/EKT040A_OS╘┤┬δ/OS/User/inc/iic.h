#ifndef __IIC_H
#define __IIC_H
#include "includes.h"


sbit IIC_SCL=P3^2;
sbit IIC_SDA=P3^3;


#define RTC_8130  1
#define RTC_2058  2

//RTC����ѡ������
#define RTC_CONFIG  RTC_2058


#define SDA_IN()	P3MDOUT=P3MDOUT&0xF7;
#define	SDA_OUT()	P3MDOUT=P3MDOUT|0x08;


void IIC_Start(void);
void IIC_Stop(void);
void IIC_Wait_Ack(void);
void IIC_Ack(void);
void IIC_NAck(void);
void IIC_Send_Byte(u8 txd);
u8 IIC_Read_Byte(void);

void Clock(void);
u8 RTC_Get_Week(u8 years,u8 month,u8 day);
void Init_Rtc(void);

#endif

