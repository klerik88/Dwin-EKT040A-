#ifndef __SYS_H__
#define __SYS_H__

#include "t5los8051.h"


typedef unsigned char   u8;
typedef unsigned short  u16;
typedef unsigned long   u32;
typedef char            s8;
typedef short           s16;
typedef long            s32;

#define DWIN_OK               (0x00)
#define DWIN_ERROR            (0xFF)
#define DWIN_NULL_POINT       (0x02)                /* ��ָ�� */
#define DWIN_PARAM_ERROR      (0x03)
#define NULL                  ((void *)0)           /* ����NULL */
#define FOSC                  (206438400UL)         /* T5L��Ƶ=����Ƶ��(11.0592M)*56/3 */
#define T1MS                  (65536-FOSC/12/1000)  /* 1MS��ʱ�� */
#define T1US                  (65536-FOSC/12/1000/1000)  /* 10uS��ʱ�� */


/*****************************************
*	    ϵͳ�ӿڱ�����ַ�궨��            *
*****************************************/
#define		NOR_FLASH				0x0008
#define		SOFT_VERSION			0x000F
#define		RTC						0x0010
#define		TP_STATUS				0x0016
#define		LED_NOW					0x0031
#define		AD_VALUE				0x0032
#define		LED_CONFIG				0x0082
#define		PIC_SET					0x0084



/*****************************************
*			wifi�ӿڱ�����ַ�궨��        *
*****************************************/
#define		EQUIPMENT_MODEL			0x0416
#define		QR_CODE					0x0450
#define		DISTRIBUTION_NETWORK	0x0498
#define		MAC_ADDR				0x0482
#define		WIFI_VER				0x0487
#define		DISTRIBUTION_STATUS		0x04A1
#define		NETWORK_STATUS			0x04A2
#define		RTC_NETWORK				0x04AC
#define		SSID					0x04B0
#define		WIFI_PASSWORD			0x04C0


extern union
{
   u8       byte[4];
   u16      word[2];
   u32      words;
}data buf;


//�궨��
#define	WDT_ON()	MUX_SEL|=0x02		/******�������Ź�*********/
#define	WDT_OFF()	MUX_SEL&=0xFD		/******�رտ��Ź�*********/
#define	WDT_RST()	MUX_SEL|=0x01		/******ι��*********/

//ȫ�ֶ���
extern u16 code union_0_buff;
extern u16 code union_1_buff;



/*�������к��������Զ���ʹ��*/
/*dbug*/

u16 Read_Dgus(u16 Dgus_Addr);
void Write_Dgus(u16 Dgus_Addr,u16 Val);
void write_dgus_vp(u16 Addr,u8* buf,u8 Len16);
void read_dgus_vp(u16 Addr,u8* buf,u8 Len16);
/*init*/
void SetPinOut(u8 Port,u8 Pin);
void SetPinIn(u8 Port,u8 Pin);
void InitCPU(void);
u16 GetPageID();
void Page_Change(u16 PageID);

#endif

