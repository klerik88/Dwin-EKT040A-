#ifndef __TIMER_H__
#define __TIMER_H__

#include "sys.h"

extern u16 data Times_FUNC;

void T0_Init(void);
void T1_Init(void);
void T2_Init(void);

void delay_us(u16 us);
void Delay_ms(u16 ms);
void RTC_Updata(void);
void InitTimer(void);

void StartTimer(u8 ID, u16 nTime);
void KillTimer(u8 ID);
u8 GetTimeOutFlag(u8 ID);
#endif


