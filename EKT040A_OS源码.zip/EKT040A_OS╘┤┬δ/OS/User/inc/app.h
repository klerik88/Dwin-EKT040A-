#ifndef __APP_H__
#define __APP_H__

/*****************************************
*	    ϵͳ�ӿڱ�����ַ�궨��            *
*****************************************/		
#define		NOR_FLASH					0x0008
#define		SOFT_VERSION			0x000F
#define		RTC								0x0010
#define		PIC_NOW						0x0014
#define		TP_STATUS					0x0016
#define		LED_NOW						0x0031
#define		AD_VALUE					0x0032
#define		SYSTEM_CONFIG			0x0080
#define		LED_CONFIG				0x0082
#define		PIC_SET						0x0084
#define 	RTC_Set						0x009C	
#define		DISTRIBUTION_NETWORK	0x0498
#define		ICL_CHANGE_FLAG	  0x0F00

/*****************************************
*			UI������ַ�궨��              *
*****************************************/
#define		TOUCH_EVENT_FLAG		0x1500



/*****************************************
*			�洢FLASH������ַ�궨��              *
*****************************************/
#define		NOR_FLASH_START			0x1200
#define 	MAGIC_NUMBER				0x1250		//��һ������ʱ





/*ȫ�ֱ������ݳ�ʼ��*/
extern u8 xdata time_hour_R242;
extern u8 xdata time_min_R251;
extern u8 xdata time_s_R252;



void The_Init_Function(void);
void Read_Nor_Flash(void);
void Write_Nor_Flash(void);
void Control_Water_level(void);
void Auxiliary_process(void);
void The_countdown_process(void);
void Control_Water_level(void);
void Ice_makeing_process(void);
void Discharge_process(void);
void Auxiliary_process(void);
void Warning_process(void);
void Set_Data_process(void);
void Parm_Set_Function(void);
void TP_Data_Ret(u8 VP);
#endif












