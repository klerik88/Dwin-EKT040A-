#ifndef __INCLUDES__
#define	__INCLUDES__


#include "t5los8051.h"
#include "sys.h"
#include "uart.h"
#include "timer.h"
#include "app.h"
#include "stdio.h"
#include "iic.h"
#include "string.h"
#include "7701S.h"




#endif





















